This theme or plugin is comprised of two parts.

(1) the PHP code and integrated HTML are licensed under the General Public
License (GPL). You will find a copy of the GPL in the same directory as this
text file.

(2) All other parts, but not limited to the CSS code, images, and design are
licensed according to the terms of your purchased license.

Read more about licensing here: http://themeforest.net/licenses
